#!/bin/bash

tar -xzf cyc-cde.tar.gz

echo '#!/bin/bash' > cyclus
echo "$PWD/cyc-cde/cde-exec /home/mouginot/.local/bin/cyclus \$@" >> cyclus
chmod a+x cyclus

echo '#!/bin/bash' > cycobj
echo "$PWD/cyc-cde/cde-exec /home/mouginot/work/app/go/bin/cycobj \$@" >> cycobj
chmod a+x cycobj

echo '#!/bin/bash' > cyan
echo "$PWD/cyc-cde/cde-exec  \$@" >> cyan
chmod a+x cyan
./cloudlus -addr=cycrun.fuelcycle.org:80 work -interval 3s -timeout=12s -whitelist=cyclus,cyan,cycobj
